<?php
/**
 * Plugin Name: Island Time BVI - WPForms Water Taxi Bridge
 * Description: Connects the WPForms Water Taxi Inquiry form to the Island Time BVI Water Taxi Booking workflow.
 * Version: 1.1.7
 * Author: Jason Itumay / iWebhacks
 * Author URI: https://iwebhacks.com/
 *
 * Original custom software architecture and development:
 * Jason Itumay / iWebhacks
 *
 * Copyright (c) 2026 Jason Itumay / iWebhacks.
 * All rights reserved except where otherwise agreed in writing.
 *
 * This bridge forms part of the custom Island Time BVI booking automation system.
 * Removal or modification of this attribution does not alter the original
 * authorship or development history of the software.
 */

if (!defined('ABSPATH')) exit;

if (!defined('ITBVI_ORIGINAL_DEVELOPER')) {
    define('ITBVI_ORIGINAL_DEVELOPER', 'Jason Itumay / iWebhacks');
}

if (!defined('ITBVI_ORIGINAL_DEVELOPER_URL')) {
    define('ITBVI_ORIGINAL_DEVELOPER_URL', 'https://iwebhacks.com/');
}

class ITBVI_WPForms_Water_Taxi_Bridge {

    const CPT = 'itbvi_water_taxi';
    const OPTION_GROUP = 'itbvi_wpforms_bridge_settings';
    const DEFAULT_FORM_ID = 14369;

    public function __construct() {
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('init', array($this, 'register_wpforms_hooks'), 20);
    }

    public function register_wpforms_hooks() {
        $form_id = absint(get_option('itbvi_wpforms_form_id', self::DEFAULT_FORM_ID));

        if ($form_id > 0) {
            add_action('wpforms_process_complete_' . $form_id, array($this, 'handle_wpforms_submission'), 10, 4);
        }

        // Safety fallback, only runs when the submitted form ID matches the configured form ID.
        add_action('wpforms_process_complete', array($this, 'handle_wpforms_submission_fallback'), 10, 4);
    }

    public function handle_wpforms_submission_fallback($fields, $entry, $form_data, $entry_id) {
        $target_form_id = absint(get_option('itbvi_wpforms_form_id', self::DEFAULT_FORM_ID));
        $submitted_form_id = isset($form_data['id']) ? absint($form_data['id']) : 0;

        if ($target_form_id <= 0 || $submitted_form_id !== $target_form_id) return;

        $this->handle_wpforms_submission($fields, $entry, $form_data, $entry_id);
    }

    public function admin_menu() {
        add_submenu_page(
            'edit.php?post_type=' . self::CPT,
            'WPForms Intake Bridge',
            'WPForms Intake',
            'manage_options',
            'itbvi-wpforms-intake-bridge',
            array($this, 'settings_page')
        );
    }

    public function register_settings() {
        $settings = array(
            'itbvi_wpforms_form_id',
            'itbvi_wpforms_field_full_name',
            'itbvi_wpforms_field_email',
            'itbvi_wpforms_field_phone',
            'itbvi_wpforms_field_trip_type',
            'itbvi_wpforms_field_arrival_date',
            'itbvi_wpforms_field_arrival_time',
            'itbvi_wpforms_field_pickup_location',
            'itbvi_wpforms_field_pickup_stt_detail',
            'itbvi_wpforms_field_pickup_bvi_detail',
            'itbvi_wpforms_field_destination',
            'itbvi_wpforms_field_destination_stt_detail',
            'itbvi_wpforms_field_destination_bvi_detail',
            'itbvi_wpforms_field_adults',
            'itbvi_wpforms_field_children',
            'itbvi_wpforms_field_infants',
            'itbvi_wpforms_field_airline_flight',
            'itbvi_wpforms_field_land_taxi_stt',
            'itbvi_wpforms_field_additional_info',
            'itbvi_wpforms_field_return_date',
            'itbvi_wpforms_field_return_pickup_location',
            'itbvi_wpforms_field_return_dropoff_location',
            // Round-trip passenger / timing / taxi fields (new WPForms architecture).
            'itbvi_wpforms_field_return_adults',
            'itbvi_wpforms_field_return_children',
            'itbvi_wpforms_field_return_infants',
            'itbvi_wpforms_field_return_flight_time_known',
            'itbvi_wpforms_field_return_flight_departure_time',
            'itbvi_wpforms_field_requested_return_pickup_time',
            'itbvi_wpforms_field_return_land_taxi_stt',
            // Legacy options kept registered for backwards compatibility, but are no longer used for new submissions.
            'itbvi_wpforms_field_return_pickup_time',
            'itbvi_wpforms_field_return_flight_details',
            'itbvi_wpforms_default_proc_fee',
            'itbvi_wpforms_enable_office_email',
            'itbvi_wpforms_enable_sheet_sync',
        );

        foreach ($settings as $setting) {
            register_setting(self::OPTION_GROUP, $setting, array(
                'type' => 'string',
                'sanitize_callback' => 'sanitize_text_field',
                'default' => ''
            ));
        }

        if (!get_option('itbvi_wpforms_form_id')) update_option('itbvi_wpforms_form_id', self::DEFAULT_FORM_ID);
        if (!get_option('itbvi_wpforms_field_full_name')) update_option('itbvi_wpforms_field_full_name', '34');
        if (!get_option('itbvi_wpforms_field_email')) update_option('itbvi_wpforms_field_email', '36');
        // Known live WPForms IDs for the revised Round Trip fields. Only seed them when no value exists yet.
        if (!get_option('itbvi_wpforms_field_return_adults')) update_option('itbvi_wpforms_field_return_adults', '62');
        if (!get_option('itbvi_wpforms_field_return_children')) update_option('itbvi_wpforms_field_return_children', '63');
        if (!get_option('itbvi_wpforms_field_return_infants')) update_option('itbvi_wpforms_field_return_infants', '64');
        if (!get_option('itbvi_wpforms_field_return_flight_time_known')) update_option('itbvi_wpforms_field_return_flight_time_known', '65');
        if (!get_option('itbvi_wpforms_field_return_flight_departure_time')) update_option('itbvi_wpforms_field_return_flight_departure_time', '66');
        if (!get_option('itbvi_wpforms_field_requested_return_pickup_time')) update_option('itbvi_wpforms_field_requested_return_pickup_time', '67');
        if (!get_option('itbvi_wpforms_field_return_land_taxi_stt')) update_option('itbvi_wpforms_field_return_land_taxi_stt', '70');
        if (!get_option('itbvi_wpforms_default_proc_fee')) update_option('itbvi_wpforms_default_proc_fee', '60');
        if (get_option('itbvi_wpforms_enable_office_email') === false) update_option('itbvi_wpforms_enable_office_email', 'yes');
        if (get_option('itbvi_wpforms_enable_sheet_sync') === false) update_option('itbvi_wpforms_enable_sheet_sync', 'yes');

    }

    public function settings_page() {
        if (!current_user_can('manage_options')) return;

        $fields = array(
            'itbvi_wpforms_form_id' => 'WPForms Form ID',
            'itbvi_wpforms_field_full_name' => 'Full Name Field ID',
            'itbvi_wpforms_field_email' => 'Email Field ID',
            'itbvi_wpforms_field_phone' => 'Phone Field ID',
            'itbvi_wpforms_field_trip_type' => 'Trip Type Field ID',
            'itbvi_wpforms_field_arrival_date' => 'Arrival Date Field ID',
            'itbvi_wpforms_field_arrival_time' => 'Arrival Time Field ID',
            'itbvi_wpforms_field_pickup_location' => 'Pickup Location Field ID',
            'itbvi_wpforms_field_pickup_stt_detail' => 'STT Hotel/Others Detail Field ID',
            'itbvi_wpforms_field_pickup_bvi_detail' => 'Within BVI Location Detail Field ID',
            'itbvi_wpforms_field_destination' => 'Destination Field ID',
            'itbvi_wpforms_field_destination_stt_detail' => 'Destination STT Location Name Field ID',
            'itbvi_wpforms_field_destination_bvi_detail' => 'Destination BVI Location Name Field ID',
            'itbvi_wpforms_field_adults' => 'Adults Field ID',
            'itbvi_wpforms_field_children' => 'Children Field ID',
            'itbvi_wpforms_field_infants' => 'Infants Field ID',
            'itbvi_wpforms_field_airline_flight' => 'Airline & Flight Field ID',
            'itbvi_wpforms_field_land_taxi_stt' => 'Land Taxi STT Field ID',
            'itbvi_wpforms_field_additional_info' => 'Additional Info Field ID',
            'itbvi_wpforms_field_return_date' => 'Return Date Field ID',
            'itbvi_wpforms_field_return_pickup_location' => 'Return Pickup Location Field ID',
            'itbvi_wpforms_field_return_dropoff_location' => 'Return Destination/Dropoff Field ID',
            'itbvi_wpforms_field_return_adults' => 'Outbound Adults Field ID',
            'itbvi_wpforms_field_return_children' => 'Outbound Children Field ID',
            'itbvi_wpforms_field_return_infants' => 'Outbound Infants Field ID',
            'itbvi_wpforms_field_return_flight_time_known' => 'Return Flight Departure Time Known? Field ID',
            'itbvi_wpforms_field_return_flight_departure_time' => 'Flight Departure Time Field ID',
            'itbvi_wpforms_field_requested_return_pickup_time' => 'Requested Return Pickup Time Field ID',
            'itbvi_wpforms_field_return_land_taxi_stt' => 'Return Land Taxi STT Field ID',
            'itbvi_wpforms_default_proc_fee' => 'Default International Processing Fee',
        );

        echo '<div class="wrap"><h1>Island Time BVI - WPForms Intake Bridge</h1>';
        echo '<p>This bridge creates Water Taxi Booking records from WPForms and normalizes the new location choices.</p>';
        echo '<form method="post" action="options.php">';
        settings_fields(self::OPTION_GROUP);
        echo '<table class="form-table" role="presentation">';

        foreach ($fields as $option => $label) {
            echo '<tr><th scope="row"><label for="' . esc_attr($option) . '">' . esc_html($label) . '</label></th><td>';
            echo '<input type="text" id="' . esc_attr($option) . '" name="' . esc_attr($option) . '" value="' . esc_attr(get_option($option, '')) . '" class="regular-text" />';
            echo '</td></tr>';
        }

        $email_enabled = get_option('itbvi_wpforms_enable_office_email', 'yes');
        $sheet_enabled = get_option('itbvi_wpforms_enable_sheet_sync', 'yes');

        echo '<tr><th scope="row">Send Office Notification</th><td><select name="itbvi_wpforms_enable_office_email">';
        echo '<option value="yes" ' . selected($email_enabled, 'yes', false) . '>Yes</option>';
        echo '<option value="no" ' . selected($email_enabled, 'no', false) . '>No</option>';
        echo '</select></td></tr>';

        echo '<tr><th scope="row">Trigger Sheet Sync</th><td><select name="itbvi_wpforms_enable_sheet_sync">';
        echo '<option value="yes" ' . selected($sheet_enabled, 'yes', false) . '>Yes</option>';
        echo '<option value="no" ' . selected($sheet_enabled, 'no', false) . '>No</option>';
        echo '</select><p class="description">Uses the main plugin function <code>itbvi_sync_booking_to_sheet_v3()</code> if available.</p></td></tr>';

        echo '</table>';
        submit_button('Save WPForms Bridge Settings');
        echo '</form>';        echo '<p><strong>Note:</strong> If a field ID is empty or wrong, this version also tries to find the value by WPForms field label. For round trips, Return Pickup is derived from the original Destination, including BVI/STT location name details, when blank or generic. Return Dropoff is derived from the original Pickup when blank or generic.</p>';
        echo '</div>';
    }

    public function handle_wpforms_submission($fields, $entry, $form_data, $entry_id) {
        if (!post_type_exists(self::CPT)) {
            error_log('ITBVI WPForms Bridge Error: Water Taxi CPT does not exist. Main booking plugin must be active.');
            return;
        }

        $mapped = $this->map_wpforms_fields($fields);
        $email = sanitize_email($mapped['email']);
        $full_name = sanitize_text_field($mapped['full_name']);

        if (!$email && !$full_name) {
            error_log('ITBVI WPForms Bridge Error: Missing guest name/email. WPForms Entry ID: ' . $entry_id);
            return;
        }

        $existing = $this->find_existing_booking_by_wpforms_entry($entry_id);
        if ($existing) {
            error_log('ITBVI WPForms Bridge: Duplicate prevented. WPForms Entry ID ' . $entry_id . ' already has post ' . $existing);
            return;
        }

        $title = 'WT Booking - ' . ($full_name ?: 'Guest') . ($mapped['arrival_date'] ? ' - ' . $mapped['arrival_date'] : '');
        $post_id = wp_insert_post(array(
            'post_type' => self::CPT,
            'post_status' => 'publish',
            'post_title' => $title,
        ), true);

        if (is_wp_error($post_id)) {
            error_log('ITBVI WPForms Bridge Error: Could not create booking. ' . $post_id->get_error_message());
            return;
        }

        $token = $this->ensure_token($post_id);

        update_post_meta($post_id, '_itbvi_wpforms_entry_id', sanitize_text_field((string)$entry_id));
        update_post_meta($post_id, '_itbvi_wpforms_form_id', sanitize_text_field((string)($form_data['id'] ?? '')));
        update_post_meta($post_id, '_itbvi_source', 'wpforms');

        foreach ($mapped as $key => $value) {
            update_post_meta($post_id, '_itbvi_' . $key, $this->sanitize_booking_value($key, $value));
        }

        // Store location detail fields according to the selected pickup type.
        if ($mapped['pickup_location'] === 'stt_hotel_other') {
            update_post_meta($post_id, '_itbvi_pickup_hotel', sanitize_text_field($mapped['pickup_stt_detail']));
            update_post_meta($post_id, '_itbvi_pickup_other', '');
        } elseif ($mapped['pickup_location'] === 'bvi_location') {
            update_post_meta($post_id, '_itbvi_pickup_other', sanitize_text_field($mapped['pickup_bvi_detail']));
            update_post_meta($post_id, '_itbvi_pickup_hotel', '');
        } else {
            update_post_meta($post_id, '_itbvi_pickup_hotel', '');
            update_post_meta($post_id, '_itbvi_pickup_other', '');
        }

        $this->apply_quote_defaults($post_id, $mapped);
        update_post_meta($post_id, '_itbvi_status', 'new');
        $this->add_log($post_id, 'wpforms_booking_submitted', 'guest', 'Booking request submitted via WPForms. WPForms Entry ID: ' . $entry_id);

        if (get_option('itbvi_wpforms_enable_sheet_sync', 'yes') === 'yes') {
            $this->trigger_sheet_sync($post_id, 'wpforms_booking_created');
        }

        if (get_option('itbvi_wpforms_enable_office_email', 'yes') === 'yes') {
            $this->send_office_notification($post_id, $mapped, $entry_id, $token);
        }
    }

    private function map_wpforms_fields($fields) {
        $mapped = array();

        $mapped['full_name'] = $this->get_value($fields, 'itbvi_wpforms_field_full_name', array('name', 'full name', 'guest name'));
        $mapped['email'] = $this->get_value($fields, 'itbvi_wpforms_field_email', array('email'));
        $mapped['phone'] = $this->get_value($fields, 'itbvi_wpforms_field_phone', array('phone'));
        $mapped['trip_type'] = $this->normalize_trip_type($this->get_value($fields, 'itbvi_wpforms_field_trip_type', array('water taxi trip', 'trip type')));
        $mapped['arrival_date'] = $this->get_value($fields, 'itbvi_wpforms_field_arrival_date', array('arrival date'));
        $mapped['arrival_time'] = $this->get_value($fields, 'itbvi_wpforms_field_arrival_time', array('arrival time'));

        $pickup_raw = $this->get_value($fields, 'itbvi_wpforms_field_pickup_location', array('pick-up location', 'pickup location', 'pick up location'), array('return', 'departure'));
        $mapped['pickup_location'] = $this->normalize_location_key($pickup_raw);
        $mapped['pickup_stt_detail'] = $this->get_value($fields, 'itbvi_wpforms_field_pickup_stt_detail', array('stt location', 'hotel/others', 'hotel others', 'hotel in stt', 'others in stt', 'location in stt'));
        $mapped['pickup_bvi_detail'] = $this->get_value($fields, 'itbvi_wpforms_field_pickup_bvi_detail', array('within bvi', 'bvi location', 'location in bvi'));

        $destination_raw = $this->get_value($fields, 'itbvi_wpforms_field_destination', array('destination', 'dropoff location', 'drop off location'), array('return', 'departure'));
        $destination_stt_detail = $this->get_value($fields, 'itbvi_wpforms_field_destination_stt_detail', array('destination stt location', 'dropoff stt location', 'drop off stt location', 'destination hotel', 'destination hotel/others', 'destination hotel others', 'destination location in stt'));
        $destination_bvi_detail = $this->get_value($fields, 'itbvi_wpforms_field_destination_bvi_detail', array('destination bvi location', 'dropoff bvi location', 'drop off bvi location', 'destination within bvi', 'destination location in bvi'));
        $mapped['destination'] = $this->build_location_display_smart($destination_raw, $destination_stt_detail, $destination_bvi_detail);
        if ($mapped['destination'] === '') $mapped['destination'] = sanitize_text_field((string)$destination_raw);
        $mapped['destination_location_type'] = $this->normalize_location_key($destination_raw);
        $mapped['destination_stt_detail'] = $destination_stt_detail;
        $mapped['destination_bvi_detail'] = $destination_bvi_detail;

        $mapped['adults'] = $this->int_value($this->get_value($fields, 'itbvi_wpforms_field_adults', array('number of adults', 'adults')));
        $mapped['children'] = $this->int_value($this->get_value($fields, 'itbvi_wpforms_field_children', array('children')));
        $mapped['infants'] = $this->int_value($this->get_value($fields, 'itbvi_wpforms_field_infants', array('infants')));
        $mapped['airline_flight'] = $this->get_value($fields, 'itbvi_wpforms_field_airline_flight', array('airline', 'flight number', 'airline and flight'));
        $mapped['land_taxi_stt'] = $this->normalize_land_taxi($this->get_value($fields, 'itbvi_wpforms_field_land_taxi_stt', array('land taxi on stt', 'land taxi'), array('return')));
        $mapped['additional_info'] = $this->get_value($fields, 'itbvi_wpforms_field_additional_info', array('additional information', 'additional info', 'notes'));

        $mapped['return_date'] = $this->get_value($fields, 'itbvi_wpforms_field_return_date', array('return date'));

        $return_pickup_raw = $this->get_value(
            $fields,
            'itbvi_wpforms_field_return_pickup_location',
            array('return pick-up location', 'return pickup location', 'return pick up location'),
            array(),
            true
        );
        $return_drop_raw = $this->get_value(
            $fields,
            'itbvi_wpforms_field_return_dropoff_location',
            array('return destination', 'return dropoff', 'return drop off', 'return drop-off', 'return destination/dropoff'),
            array(),
            true
        );

        $pickup_display = $this->pickup_display_from_mapped($mapped);
        $destination_display = sanitize_text_field((string)$mapped['destination']);

        $return_pickup_display = $this->build_location_display_smart($return_pickup_raw);
        $return_drop_display = $this->build_location_display_smart($return_drop_raw);

        if ($mapped['trip_type'] === 'round_trip') {
            if ($return_pickup_display === ''
                || $this->same_location_text($return_pickup_display, $pickup_display)
                || $this->is_generic_location_display($return_pickup_display)
            ) {
                $return_pickup_display = $destination_display;
            }
            if ($return_drop_display === ''
                || $this->same_location_text($return_drop_display, $destination_display)
                || $this->is_generic_location_display($return_drop_display)
            ) {
                $return_drop_display = $pickup_display;
            }
        }

        $mapped['return_pickup_location'] = $return_pickup_display;
        $mapped['return_dropoff_location'] = $return_drop_display;

        // Revised Round Trip fields: keep guest flight timing, requested pickup time, passenger counts,
        // and return land taxi as separate data points. Do not treat flight departure time as pickup time.
        if ($mapped['trip_type'] === 'round_trip') {
            $mapped['return_adults'] = $this->int_value($this->get_value($fields, 'itbvi_wpforms_field_return_adults', array('outbound adults', 'return adults')));
            $mapped['return_children'] = $this->int_value($this->get_value($fields, 'itbvi_wpforms_field_return_children', array('outbound children', 'return children')));
            $mapped['return_infants'] = $this->int_value($this->get_value($fields, 'itbvi_wpforms_field_return_infants', array('outbound infants', 'return infants')));
            $mapped['return_flight_time_known'] = $this->normalize_return_flight_status($this->get_value($fields, 'itbvi_wpforms_field_return_flight_time_known', array('do you know your return flight departure time', 'return flight departure time')));
            $mapped['return_flight_departure_time'] = $this->get_value($fields, 'itbvi_wpforms_field_return_flight_departure_time', array('flight departure time'), array('arrival'));
            $mapped['requested_return_pickup_time'] = $this->get_value($fields, 'itbvi_wpforms_field_requested_return_pickup_time', array('preferred return pickup time', 'requested return pickup time', 'return pickup time'), array('flight departure'));
            $mapped['return_land_taxi_stt'] = $this->normalize_land_taxi($this->get_value($fields, 'itbvi_wpforms_field_return_land_taxi_stt', array('return land taxi on stt', 'return land taxi'), array(), true));

            // Compatibility field: only mirror the guest's requested pickup time, never the flight departure time.
            // The main plugin will later gain a separate admin-confirmed return pickup time.
            $mapped['return_pickup_time'] = $mapped['requested_return_pickup_time'];
        } else {
            $mapped['return_adults'] = 0;
            $mapped['return_children'] = 0;
            $mapped['return_infants'] = 0;
            $mapped['return_flight_time_known'] = '';
            $mapped['return_flight_departure_time'] = '';
            $mapped['requested_return_pickup_time'] = '';
            $mapped['return_land_taxi_stt'] = 'not_applicable';
            $mapped['return_pickup_time'] = '';
        }

        // Legacy return airline/flight-number field is intentionally retired for new submissions.
        $mapped['return_flight_details'] = '';

        return $mapped;
    }

    private function get_value($fields, $option_key, $label_needles = array(), $exclude_needles = array(), $prefer_return = false) {
        $field_id = trim((string)get_option($option_key, ''));

        if ($field_id !== '' && isset($fields[$field_id])) {
            return $this->field_value($fields[$field_id]);
        }

        if ($field_id !== '') {
            foreach ($fields as $id => $field) {
                if ((string)$id === $field_id) return $this->field_value($field);
            }
        }

        $best = '';
        foreach ($fields as $field) {
            $name = isset($field['name']) ? strtolower((string)$field['name']) : '';
            $name_norm = preg_replace('/\s+/', ' ', str_replace(array('-', '_'), ' ', $name));
            $value = $this->field_value($field);
            if ($value === '') continue;

            $has_all = true;
            foreach ((array)$label_needles as $needle) {
                $needle = strtolower((string)$needle);
                if ($needle !== '' && strpos($name_norm, $needle) === false) {
                    $has_all = false;
                    break;
                }
            }
            if (!$has_all) continue;

            $excluded = false;
            foreach ((array)$exclude_needles as $ex) {
                $ex = strtolower((string)$ex);
                if ($ex !== '' && strpos($name_norm, $ex) !== false) {
                    $excluded = true;
                    break;
                }
            }
            if ($excluded) continue;

            if ($prefer_return && strpos($name_norm, 'return') === false && strpos($name_norm, 'departure') === false) {
                if ($best === '') $best = $value;
                continue;
            }

            return $value;
        }

        return $best;
    }

    private function field_value($field) {
        if (isset($field['value'])) {
            $value = $field['value'];
            if (is_array($value)) return implode(', ', array_map('sanitize_text_field', $value));
            return trim((string)$value);
        }
        return '';
    }

    private function normalize_location_key($raw) {
        $raw = is_array($raw) ? implode(' ', $raw) : (string)$raw;
        $v = strtolower(trim($raw));
        $v = str_replace(array('&amp;', '&'), ' and ', $v);
        $v = preg_replace('/[^a-z0-9]+/', '_', $v);
        $v = trim($v, '_');

        if (in_array($v, array('stt_airport', 'cruz_bay', 'stt_hotel_other', 'bvi_location'), true)) return $v;
        if (in_array($v, array('hotel', 'other'), true)) return 'stt_hotel_other';

        if (strpos($v, 'bvi') !== false || strpos($v, 'tortola') !== false || strpos($v, 'virgin_gorda') !== false || strpos($v, 'jost') !== false || strpos($v, 'nanny_cay') !== false || strpos($v, 'west_end') !== false || strpos($v, 'road_town') !== false) {
            return 'bvi_location';
        }
        if (strpos($v, 'cruz') !== false || strpos($v, 'st_john') !== false || strpos($v, 'saint_john') !== false) return 'cruz_bay';
        if (strpos($v, 'hotel') !== false || strpos($v, 'other') !== false || strpos($v, 'others') !== false) return 'stt_hotel_other';
        if (strpos($v, 'airport') !== false || strpos($v, 'stt') !== false || strpos($v, 'thomas') !== false) return 'stt_airport';

        return $raw === '' ? '' : 'stt_airport';
    }

    private function build_location_display($raw, $detail = '') {
        $key = $this->normalize_location_key($raw);
        $detail = trim((string)$detail);
        $label = $this->location_label($key ?: $raw);
        if ($detail !== '') $label .= ' - ' . $detail;
        return $label;
    }

    private function is_structured_location_choice($raw) {
        $raw = trim((string)$raw);
        if ($raw === '') return false;
        $v = strtolower($raw);
        $v = str_replace(array('&amp;', '&'), ' and ', $v);
        $v = preg_replace('/[^a-z0-9]+/', '_', $v);
        $v = trim($v, '_');
        return in_array($v, array(
            'stt_airport',
            'cruz_bay',
            'cruz_bay_st_john',
            'hotel_others_in_stt',
            'hotel_other_in_stt',
            'stt_hotel_other',
            'within_bvi_location',
            'bvi_location',
        ), true);
    }

    private function build_location_display_smart($raw, $stt_detail = '', $bvi_detail = '') {
        $raw = trim((string)$raw);
        if ($raw === '') return '';

        $key = $this->normalize_location_key($raw);
        $stt_detail = trim((string)$stt_detail);
        $bvi_detail = trim((string)$bvi_detail);
        $detail = '';

        if ($key === 'stt_hotel_other') {
            $detail = $stt_detail;
        } elseif ($key === 'bvi_location') {
            $detail = $bvi_detail;
        }

        // Preserve free-text destinations like "West End Tortola" instead of converting them to a generic label.
        if (!$this->is_structured_location_choice($raw) && $detail === '') {
            return sanitize_text_field($raw);
        }

        return $this->build_location_display($key, $detail);
    }

    private function is_generic_location_display($display) {
        $display = trim((string)$display);
        return in_array($display, array(
            'STT Airport',
            'Cruz Bay, St. John',
            'Hotel/Others in STT',
            'Within BVI Location',
        ), true);
    }

    private function location_label($key) {
        $key = (string)$key;
        $map = array(
            'stt_airport' => 'STT Airport',
            'cruz_bay' => 'Cruz Bay, St. John',
            'stt_hotel_other' => 'Hotel/Others in STT',
            'hotel' => 'Hotel/Others in STT',
            'other' => 'Hotel/Others in STT',
            'bvi_location' => 'Within BVI Location',
        );
        return isset($map[$key]) ? $map[$key] : $key;
    }

    private function pickup_display_from_mapped($mapped) {
        $label = $this->location_label($mapped['pickup_location']);
        if ($mapped['pickup_location'] === 'stt_hotel_other' && trim((string)$mapped['pickup_stt_detail']) !== '') {
            $label .= ' - ' . trim((string)$mapped['pickup_stt_detail']);
        }
        if ($mapped['pickup_location'] === 'bvi_location' && trim((string)$mapped['pickup_bvi_detail']) !== '') {
            $label .= ' - ' . trim((string)$mapped['pickup_bvi_detail']);
        }
        return $label;
    }

    private function apply_quote_defaults($post_id, $mapped) {
        $adults = absint($mapped['adults']);
        $children = absint($mapped['children']);
        $infants = absint($mapped['infants']);
        $total_pax = $adults + $children + $infants;
        $paying_pax = $adults + $children;
        $is_bvi_local_pickup = ($mapped['pickup_location'] === 'bvi_location');
        $is_round = ($mapped['trip_type'] === 'round_trip');

        $return_adults = $is_round ? absint($mapped['return_adults']) : 0;
        $return_children = $is_round ? absint($mapped['return_children']) : 0;
        $return_infants = $is_round ? absint($mapped['return_infants']) : 0;
        $return_paying_pax = $return_adults + $return_children;

        update_post_meta($post_id, '_itbvi_quote_party_text', 'your party of ' . $total_pax);
        update_post_meta($post_id, '_itbvi_quote_from', $this->pickup_display_from_mapped($mapped));
        update_post_meta($post_id, '_itbvi_quote_to', sanitize_text_field($mapped['destination']));
        update_post_meta($post_id, '_itbvi_quote_valid_days', '30');
        update_post_meta($post_id, '_itbvi_quote_rate_type', 'per_person');
        update_post_meta($post_id, '_itbvi_q_per_person_adult_pax', (string)$adults);
        update_post_meta($post_id, '_itbvi_q_per_person_child_pax', (string)$children);
        update_post_meta($post_id, '_itbvi_q_under3_pax', (string)$infants);
        update_post_meta($post_id, '_itbvi_q_late_cost', '$50.00');
        update_post_meta($post_id, '_itbvi_q_late_pax', '0');

        // Return passenger counts are stored on their dedicated booking meta keys and used directly by Quote Builder.
        update_post_meta($post_id, '_itbvi_return_adults', (string)$return_adults);
        update_post_meta($post_id, '_itbvi_return_children', (string)$return_children);
        update_post_meta($post_id, '_itbvi_return_infants', (string)$return_infants);

        if ($is_bvi_local_pickup) {
            update_post_meta($post_id, '_itbvi_q_proc_cost', '$0.00');
            update_post_meta($post_id, '_itbvi_q_proc_pax', '0');
        } else {
            $fee = (float)get_option('itbvi_wpforms_default_proc_fee', '60');
            update_post_meta($post_id, '_itbvi_q_proc_cost', '$' . number_format($fee, 2));
            update_post_meta($post_id, '_itbvi_q_proc_pax', (string)$paying_pax);
        }

        // For a Round Trip, default the outbound international-processing pax from the actual outbound
        // adults + children. Julien can still edit this in Quote Builder when a particular trip does not require it.
        update_post_meta($post_id, '_itbvi_q_return_proc_pax', $is_round ? (string)$return_paying_pax : '0');
    }

    private function send_office_notification($post_id, $mapped, $entry_id, $token) {
        $recipients = array('info@islandtimeltd.com', 'marketing@islandtimeltd.com');
        $extra = sanitize_email(get_option('itbvi_wt_office_email', ''));
        if ($extra && !in_array($extra, $recipients, true)) $recipients[] = $extra;

        $quote_page = trim((string)get_option('itbvi_wt_quote_page_url', ''));
        $confirm_page = trim((string)get_option('itbvi_wt_confirmation_page_url', ''));
        $quote_link = $quote_page ? add_query_arg('t', rawurlencode($token), $quote_page) : '';
        $confirm_link = $confirm_page ? add_query_arg('t', rawurlencode($token), $confirm_page) : '';
        $pickup_display = $this->pickup_display_from_mapped($mapped);

        $subject = 'New Water Taxi Booking Request: ' . ($mapped['full_name'] ?: 'Guest');
        $body = "A new Water Taxi booking request was submitted via WPForms.\n\n";
        $body .= "WordPress Booking ID: " . $post_id . "\n";
        $body .= "WPForms Entry ID: " . $entry_id . "\n\n";
        $body .= "Guest Name: " . $mapped['full_name'] . "\n";
        $body .= "Email: " . $mapped['email'] . "\n";
        $body .= "Phone: " . $mapped['phone'] . "\n";
        $trip_type_label = ($mapped['trip_type'] === 'round_trip') ? 'Round Trip' : 'One Way';
        $body .= "Trip Type: " . $trip_type_label . "\n";
        $body .= "Arrival Date: " . $mapped['arrival_date'] . "\n";
        $body .= "Arrival Time: " . $mapped['arrival_time'] . "\n";
        $body .= "Pickup: " . $pickup_display . "\n";
        $body .= "Destination: " . $mapped['destination'] . "\n\n";
        $body .= "Inbound Passengers:\n";
        $body .= "Adults: " . $mapped['adults'] . "\n";
        $body .= "Children: " . $mapped['children'] . "\n";
        $body .= "Infants: " . $mapped['infants'] . "\n\n";
        $body .= "Airline & Flight: " . $mapped['airline_flight'] . "\n";
        $body .= "Land Taxi on STT: " . $this->land_taxi_label($mapped['land_taxi_stt']) . "\n\n";
        if ($mapped['trip_type'] === 'round_trip') {
            $body .= "OUTBOUND / RETURN TRIP:\n";
            $body .= "Return Date: " . $mapped['return_date'] . "\n";
            $body .= "Return Pickup: " . $mapped['return_pickup_location'] . "\n";
            $body .= "Return Dropoff: " . $mapped['return_dropoff_location'] . "\n";
            $body .= "Outbound Adults: " . $mapped['return_adults'] . "\n";
            $body .= "Outbound Children: " . $mapped['return_children'] . "\n";
            $body .= "Outbound Infants: " . $mapped['return_infants'] . "\n";
            if ($mapped['return_flight_departure_time'] !== '') {
                $body .= "Flight Departure Time: " . $mapped['return_flight_departure_time'] . "\n";
            }
            if ($mapped['requested_return_pickup_time'] !== '') {
                $body .= "Requested Return Pickup Time: " . $mapped['requested_return_pickup_time'] . "\n";
            }
            $body .= "Return Land Taxi on STT: " . $this->land_taxi_label($mapped['return_land_taxi_stt']) . "\n\n";
        }
        $body .= "Additional Info:\n" . $mapped['additional_info'] . "\n\n";
        $body .= "Admin Edit Link:\n" . admin_url('post.php?post=' . $post_id . '&action=edit') . "\n\n";
        if ($quote_link) $body .= "Guest Quote Link:\n" . $quote_link . "\n\n";
        if ($confirm_link) $body .= "Guest Confirmation Link:\n" . $confirm_link . "\n\n";

        wp_mail($recipients, $subject, $body, array('Content-Type: text/plain; charset=UTF-8'));
    }

    private function same_location_text($a, $b) {
        $a = strtolower(trim((string)$a));
        $b = strtolower(trim((string)$b));
        $a = preg_replace('/[^a-z0-9]+/', '', $a);
        $b = preg_replace('/[^a-z0-9]+/', '', $b);
        return $a !== '' && $b !== '' && $a === $b;
    }

    private function trigger_sheet_sync($post_id, $stage) {
        $post_id = absint($post_id);
        update_post_meta($post_id, '_itbvi_bridge_sheet_sync_status', 'started');
        update_post_meta($post_id, '_itbvi_bridge_sheet_sync_error', '');

        if (function_exists('itbvi_sync_booking_to_sheet_v3')) {
            $result = itbvi_sync_booking_to_sheet_v3($post_id, $stage);
            if ($result) {
                update_post_meta($post_id, '_itbvi_bridge_sheet_sync_status', 'success_main_sync');
                update_post_meta($post_id, '_itbvi_bridge_sheet_sync_at', current_time('mysql'));
                return true;
            }
            $last_error = get_post_meta($post_id, '_itbvi_sheet_last_error', true);
            if ($last_error) {
                update_post_meta($post_id, '_itbvi_bridge_sheet_sync_error', sanitize_text_field($last_error));
            }
        }

        if (function_exists('itbvi_wt_build_sheet_payload')) {
            $payload = itbvi_wt_build_sheet_payload($post_id, $stage);
        } else {
            $payload = array(
                'stage' => $stage,
                'entry_id' => (string)$post_id,
                'booking_token' => (string)get_post_meta($post_id, '_itbvi_token', true),
                'booking_uid' => (string)get_post_meta($post_id, '_itbvi_booking_uid', true),
                'created_at' => current_time('mysql'),
                'booking_status' => 'NEW',
                'trip_type' => get_post_meta($post_id, '_itbvi_trip_type', true) === 'round_trip' ? 'Round Trip' : 'One Way',
                'customer_name' => (string)get_post_meta($post_id, '_itbvi_full_name', true),
                'customer_email' => (string)get_post_meta($post_id, '_itbvi_email', true),
                'customer_phone' => (string)get_post_meta($post_id, '_itbvi_phone', true),
                'service_type' => 'Water Taxi',
                'arrival_date' => (string)get_post_meta($post_id, '_itbvi_arrival_date', true),
                'arrival_time' => (string)get_post_meta($post_id, '_itbvi_arrival_time', true),
                'return_date' => (string)get_post_meta($post_id, '_itbvi_return_date', true),
                'return_pickup_time' => (string)get_post_meta($post_id, '_itbvi_return_pickup_time', true),
                'pickup_location' => $this->location_label(get_post_meta($post_id, '_itbvi_pickup_location', true)),
                'dropoff_location' => (string)get_post_meta($post_id, '_itbvi_destination', true),
                'return_pickup_location' => (string)get_post_meta($post_id, '_itbvi_return_pickup_location', true),
                'return_dropoff_location' => (string)get_post_meta($post_id, '_itbvi_return_dropoff_location', true),
                'land_taxi_arrival' => $this->land_taxi_sheet_value(get_post_meta($post_id, '_itbvi_land_taxi_stt', true)),
                'land_taxi_departure' => $this->land_taxi_sheet_value(get_post_meta($post_id, '_itbvi_return_land_taxi_stt', true)),
                'party_size' => (string)(absint(get_post_meta($post_id, '_itbvi_adults', true)) + absint(get_post_meta($post_id, '_itbvi_children', true)) + absint(get_post_meta($post_id, '_itbvi_infants', true))),
                'adults' => (string)absint(get_post_meta($post_id, '_itbvi_adults', true)),
                'children' => (string)absint(get_post_meta($post_id, '_itbvi_children', true)),
                'infants' => (string)absint(get_post_meta($post_id, '_itbvi_infants', true)),
                'return_adults' => (string)absint(get_post_meta($post_id, '_itbvi_return_adults', true)),
                'return_children' => (string)absint(get_post_meta($post_id, '_itbvi_return_children', true)),
                'return_infants' => (string)absint(get_post_meta($post_id, '_itbvi_return_infants', true)),
                'return_flight_departure_time' => (string)get_post_meta($post_id, '_itbvi_return_flight_departure_time', true),
                'requested_return_pickup_time' => (string)get_post_meta($post_id, '_itbvi_requested_return_pickup_time', true),
                'qb_sync_status' => 'NOT_READY',
                'qb_transaction_type' => 'Sales Receipt',
                'notes_internal' => 'Created by WPForms bridge at ' . current_time('mysql'),
            );
        }

        $url = trim((string)get_option('itbvi_wt_sheet_sync_webhook_url', ''));
        if ($url === '') $url = trim((string)get_option('itbvi_wt_make_webhook_url', ''));
        if ($url === '') {
            update_post_meta($post_id, '_itbvi_bridge_sheet_sync_status', 'failed');
            update_post_meta($post_id, '_itbvi_bridge_sheet_sync_error', 'Missing Sheet Sync Make.com Webhook URL.');
            return false;
        }

        $secret = trim((string)get_option('itbvi_wt_sheet_sync_webhook_secret', ''));
        if ($secret !== '') $payload['secret'] = $secret;

        $response = wp_remote_post($url, array(
            'timeout' => 20,
            'headers' => array('Content-Type' => 'application/json'),
            'body' => wp_json_encode($payload),
        ));

        if (is_wp_error($response)) {
            update_post_meta($post_id, '_itbvi_bridge_sheet_sync_status', 'failed');
            update_post_meta($post_id, '_itbvi_bridge_sheet_sync_error', $response->get_error_message());
            return false;
        }

        $code = (int)wp_remote_retrieve_response_code($response);
        if ($code < 200 || $code >= 300) {
            update_post_meta($post_id, '_itbvi_bridge_sheet_sync_status', 'failed');
            update_post_meta($post_id, '_itbvi_bridge_sheet_sync_error', 'Make.com HTTP ' . $code . ': ' . wp_remote_retrieve_body($response));
            return false;
        }

        update_post_meta($post_id, '_itbvi_bridge_sheet_sync_status', 'success_direct_webhook');
        update_post_meta($post_id, '_itbvi_bridge_sheet_sync_at', current_time('mysql'));
        update_post_meta($post_id, '_itbvi_bridge_sheet_sync_error', '');
        return true;
    }

    private function sanitize_booking_value($key, $value) {
        if ($key === 'email') return sanitize_email($value);
        if (in_array($key, array('additional_info'), true)) return sanitize_textarea_field($value);
        if (in_array($key, array('adults', 'children', 'infants', 'return_adults', 'return_children', 'return_infants'), true)) return (string)absint($value);
        return sanitize_text_field((string)$value);
    }

    private function normalize_trip_type($value) {
        $v = strtolower(trim((string)$value));
        return (strpos($v, 'round') !== false || strpos($v, 'return') !== false) ? 'round_trip' : 'one_way';
    }

    private function normalize_yes_no($value) {
        $v = strtolower(trim((string)$value));
        return (in_array($v, array('yes', 'y', 'true', '1'), true) || strpos($v, 'yes') !== false) ? 'yes' : 'no';
    }

    private function normalize_land_taxi($value) {
        $v = strtolower(trim((string)$value));
        if ($v === '') return 'not_applicable';
        if (strpos($v, 'not applicable') !== false || strpos($v, 'n/a') !== false || $v === 'na') return 'not_applicable';
        if (in_array($v, array('yes', 'y', 'true', '1'), true) || strpos($v, 'yes') !== false) return 'yes';
        if (in_array($v, array('no', 'n', 'false', '0'), true) || $v === 'no') return 'no';
        return sanitize_key(str_replace(' ', '_', $v));
    }

    private function land_taxi_label($value) {
        $v = $this->normalize_land_taxi($value);
        if ($v === 'yes') return 'YES';
        if ($v === 'no') return 'NO';
        return 'Not Applicable';
    }

    private function land_taxi_sheet_value($value) {
        $v = $this->normalize_land_taxi($value);
        if ($v === 'yes') return 'Y';
        if ($v === 'no') return 'N';
        return 'N/A';
    }

    private function normalize_return_flight_status($value) {
        $v = strtolower(trim((string)$value));
        if ($v === '') return '';
        if (strpos($v, 'not applicable') !== false || strpos($v, 'not catching') !== false) return 'not_applicable';
        if (strpos($v, 'no') !== false || strpos($v, 'not yet') !== false) return 'no_not_yet';
        if (strpos($v, 'yes') !== false) return 'yes';
        return sanitize_key(str_replace(' ', '_', $v));
    }

    private function int_value($value) {
        if (is_array($value)) $value = implode(' ', $value);
        preg_match('/\d+/', (string)$value, $matches);
        return isset($matches[0]) ? absint($matches[0]) : 0;
    }

    private function ensure_token($post_id) {
        $token = get_post_meta($post_id, '_itbvi_token', true);
        if (!$token) {
            $token = wp_generate_password(32, false, false);
            update_post_meta($post_id, '_itbvi_token', $token);
        }
        return $token;
    }

    private function add_log($post_id, $event, $actor, $message) {
        $logs = get_post_meta($post_id, '_itbvi_logs', true);
        if (!is_array($logs)) $logs = array();
        $logs[] = array(
            'time' => current_time('mysql'),
            'event' => sanitize_text_field($event),
            'actor' => sanitize_text_field($actor),
            'message' => sanitize_text_field($message),
        );
        update_post_meta($post_id, '_itbvi_logs', $logs);
    }

    private function find_existing_booking_by_wpforms_entry($entry_id) {
        $q = new WP_Query(array(
            'post_type' => self::CPT,
            'post_status' => 'any',
            'posts_per_page' => 1,
            'fields' => 'ids',
            'meta_query' => array(array(
                'key' => '_itbvi_wpforms_entry_id',
                'value' => sanitize_text_field((string)$entry_id),
                'compare' => '='
            ))
        ));
        return !empty($q->posts) ? absint($q->posts[0]) : 0;
    }
}

new ITBVI_WPForms_Water_Taxi_Bridge();